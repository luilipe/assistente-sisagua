globalThis.SISAGUA_BATCHES = [];
